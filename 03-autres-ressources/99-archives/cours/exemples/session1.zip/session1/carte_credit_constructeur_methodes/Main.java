
public class Main {
    public static void main(String[] args) {

        CreditCard cb = new CreditCard("VISA", 1223333333333333L);

        User user = new User();
        user.firstName = "FirstName";
        user.lastName = "Lastname";
        user.age = 21;

        user.setCreditCard(cb);

        System.out.println(user.firstName + ", " + user.getCreditCard().type + ": " + user.getCreditCard().ccNumber);

    }
}