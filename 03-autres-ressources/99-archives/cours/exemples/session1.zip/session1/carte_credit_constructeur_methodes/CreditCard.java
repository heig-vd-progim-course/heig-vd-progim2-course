class CreditCard {
    String type;
    long ccNumber;

    CreditCard(String type, long ccNumber){
        this.type = type;
        this.ccNumber = ccNumber;
    }
}
