class User {
    String firstName;
    String lastName;
    int age;
    CreditCard creditCard;

    CreditCard getCreditCard(){
        return this.creditCard;
    }

    void setCreditCard(CreditCard creditCard){
        this.creditCard = creditCard;
    }
}
