class User {
    String firstName;
    String lastName;
    int age;
    CreditCard creditCard;
}
