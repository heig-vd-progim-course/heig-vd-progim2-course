class CreditCard {
    String type;
    long ccNumber;
}
