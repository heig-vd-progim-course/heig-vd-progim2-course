
public class Main {
    public static void main(String[] args) {

        CreditCard cb = new CreditCard();
        cb.type = "VISA";
        cb.ccNumber = 1223333333333333L;

        User user = new User();
        user.firstName = "FirstName";
        user.lastName = "Lastname";
        user.age = 21;
        user.creditCard = cb;

        System.out.println(user.firstName + ", " + user.creditCard.type + ": " + user.creditCard.ccNumber);

    }
}