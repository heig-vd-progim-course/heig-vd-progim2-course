class Flight {
    String name;
    int speed;
    int height;
    String destination;
}