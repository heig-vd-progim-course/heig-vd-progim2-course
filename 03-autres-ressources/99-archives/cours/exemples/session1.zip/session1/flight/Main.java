

public class Main {
    public static void main(String[] args) {
        Flight[] flights = new Flight[1];

        Flight a = new Flight();
        a.name = "LA1357";
        a.speed = 987;
        a.destination = "LAX";
        a.height = 10987;

        flights[0] = a;

        for(Flight flight : flights) {
            System.out.println(flight.name + ", " + flight.speed + ", " + flight.destination);
        }
    }
}