import checkout.*;

public class Main {
    public static void main(String[] args) {

        Shoes shoes1 = new Shoes("shoes1", 49, 39);
        Shoes shoes2 = new Shoes("shoes1", 59, 29);
        Table table1 = new Table("table1", 39, 209);
        App app1 = new App("app1", 9, 1.1, "https://");
        License lic1 = new License("lic1", 39, 2.2, "https://");



        //System.out.println(shoes1.toString());

        ShoppingCart sc = new ShoppingCart();
        sc.addProduct(shoes1);
        sc.addProduct(shoes2);
        sc.addProduct(table1);
        sc.addProduct(app1);
        sc.addProduct(lic1);

        for(Product p : sc.getCartProducts()){
            System.out.println(p.toString());
        }
        System.out.println(sc.getTotalCartPrice("CHF"));

    }
}