package checkout;

import java.util.ArrayList;


public class ShoppingCart {
    ArrayList<Product> products = new ArrayList<>();

    public void addProduct(Product product){
        this.products.add(product);
    }

    public ArrayList<Product> getCartProducts(){
        return this.products;
    }

    public int getTotalCartPrice(){
        int totalCost = 0;
        for(Product p : this.products){
            totalCost += p.getPrice() + p.getShippingCosts();
        }
        return totalCost;
    }

    public String getTotalCartPrice(String monnaie){
        return this.getTotalCartPrice() + " " + monnaie;
    }

}
