package checkout;

public class Shoes extends Product {
    private int size;
    private int shippingCosts = 9;

    public Shoes(String name, int price, int size){
        super(name, price);
        this.size = size;
    }

    public int getSize() {
        return size;
    }

    @Override
    public int getShippingCosts() {
        return this.shippingCosts;
    }

    @Override
    public String toString() {
        return "Shoes: " + this.size;
    }
}
