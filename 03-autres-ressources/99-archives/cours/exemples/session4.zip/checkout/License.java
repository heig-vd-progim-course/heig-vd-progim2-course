package checkout;

public class License extends Product {
    private double version;
    private String link;

    public License(String name, int price, double version, String link) {
        super(name, price);
        this.version = version;
        this.link = link;
    }

    @Override
    public int getShippingCosts() {
        return 0;
    }
}
