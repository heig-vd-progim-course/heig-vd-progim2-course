package checkout;

public class Table extends Product{
    private int poids;

    public Table(String name, int price,int poids) {
        super(name, price);
        this.poids = poids;
    }

    @Override
    public String toString(){
        return "Table: " + this.poids;
    }

    @Override
    public int getShippingCosts(){
        return this.poids * 30;
    }
}
