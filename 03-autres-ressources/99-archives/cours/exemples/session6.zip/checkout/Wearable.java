package checkout;

public interface Wearable {
    int getSize();
}
