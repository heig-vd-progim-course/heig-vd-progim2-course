package checkout;

public interface Downloadable {
    String getDownloadLink();
    double getVersion();
}
