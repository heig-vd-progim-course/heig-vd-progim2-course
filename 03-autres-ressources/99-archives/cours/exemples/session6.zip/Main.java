import checkout.*;

import java.math.BigDecimal;
import java.util.*;


public class Main extends Object{
    public static void main(String[] args) {

        Shoes shoes1 = new Shoes("shoes1", 49, 39);
        Shoes shoes2 = new Shoes("shoes1", 559, 29);
        Table table1 = new Table("table1", 539, 209);
        App app1 = new App("app1", 9, 1.1, "https://");
        License lic1 = new License("lic1", 39, 2.2, "https://");

        //Exemples interfaces
        //System.out.println(Product.getCounter());

        List<Shoes> shoesList = new ArrayList<>();
        shoesList.add(shoes1);
        shoesList.add(shoes2);

        Shoes shoes3 = new Shoes("shoes1", 49, 39);
        System.out.println(shoesList.contains(shoes3));

        /*for(Shoes s : shoesList){
            if(s.getPrice() > 500){
                shoesList.remove(s);
            }
        }*/
        Iterator<Shoes> it = shoesList.iterator();
        System.out.println(shoesList.size());
        while (it.hasNext()){
            Shoes s = it.next();
            if(s.getPrice() > 500){
                it.remove();
            }
        }
        System.out.println(shoesList.size());

        List<String> arrayList = new ArrayList<>();
        List<String> linkedlist = new LinkedList<>();

        long start = System.currentTimeMillis();
        for(int i=0; i<300000;i++){
            linkedlist.add(0, "aaa");
        }
        System.out.println(System.currentTimeMillis() - start);

        Deque<String> monDeque = new ArrayDeque<>();
        monDeque.add("first");
        monDeque.add("second");
        monDeque.add("third");

        System.out.println(monDeque.size());
        System.out.println(monDeque.poll());
        System.out.println(monDeque.size());



       /* ShoppingCart sc = new ShoppingCart();
        sc.addProduct(shoes1);
        sc.addProduct(shoes2);
        sc.addProduct(table1);
        sc.addProduct(app1);
        sc.addProduct(lic1);


        for( Product p : sc.getCartProducts()){
            if(p instanceof Downloadable){
                System.out.println("Download here:" + ((Downloadable) p).getDownloadLink());
            }
            System.out.println(p.toString());
        }
        System.out.println(sc.getTotalCartPrice("CHF"));

        //Exemples classes Integer,... , BigDecimal
        Integer integerVar = Integer.valueOf(3);
        Double doubleVar = Double.valueOf(3.5);
        int j = 3;
        ArrayList<Integer> intList = new ArrayList<>();
        intList.add(j);
        intList.add(j);
        double d1 = 0.1;
        double d2 = 0.2;
        double d3 = d1+d2;
        System.out.println(d3);
        BigDecimal b3 = new BigDecimal("2.5");
        BigDecimal b1 = BigDecimal.valueOf(0.1);
        BigDecimal b2 = BigDecimal.valueOf(d2);
        System.out.println(b1.add(b2));

        // Exemples référence/valeur
        int i = 10;
        System.out.println(i);
        j = i;
        System.out.println(j);
        i++;
        System.out.println(i);
        System.out.println(j);

        Shoes shoes4 = new Shoes("shoes1", 49, 39);
        System.out.println(shoes4.getSize());
        Shoes shoes5 = shoes4;
        System.out.println(shoes5.getSize());
        shoes4.setSize(43);
        System.out.println(shoes5.getSize());

        System.out.println(j==i);
        System.out.println(shoes4==shoes5);
        Shoes shoes6 = new Shoes("shoes1", 49, 43);
        System.out.println(shoes4.equals(shoes6));

        List liste = new ArrayList();
        liste.add("weewewe");
        liste.add(3);

        String monString = (String) liste.get(0);
*/
    }
}