package checkout;

public abstract class Product {
    private String name;
    private int price;
    private static int counter = 0;

    public Product(String name, int price){
        this.name = name;
        this.price = price;
        counter++;
    }

    public static int getCounter(){
        return counter;
    }

    public String getName() {
        return this.name;
    }
    public int getPrice(){
        return this.price;
    }
    public abstract double getShippingCosts();

}