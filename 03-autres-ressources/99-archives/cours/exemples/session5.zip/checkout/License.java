package checkout;

public class License extends Product implements Downloadable {
    private double version;
    private String link;


    public License(String name, int price,  double version, String link) {
        super(name, price);
        this.version = version;
        this.link = link;
    }

    @Override
    public double getShippingCosts() {
        return 0;
    }

    @Override
    public String getDownloadLink() {
        return this.link;
    }

    @Override
    public double getVersion() {
        return this.version;
    }
}
