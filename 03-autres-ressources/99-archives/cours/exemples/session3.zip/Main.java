import exo.produits.Product;
import exo.produits.Shoes;
import exo.produits.ShoppingCart;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Product prod1 = new Product("produit1", 999, 36);
        Product prod2 = new Product("produit2", 9999, 36);
        Product prod3 = new Product("produit3", 9999, 36);
        Shoes shoes = new Shoes("shoes", 999, 36, 44);

        ShoppingCart shopCart = new ShoppingCart();
        shopCart.addProduct(prod1);
        shopCart.addProduct(prod2);
        shopCart.addProduct(prod3);
        shopCart.addProduct(shoes);
        System.out.println(shopCart.getTotalShoppingCart());

        ArrayList<Product> prods = shopCart.getProduits();
        //Product prod = prods.get(3);
        //Product prod = prods.get(2); => ERROR
        ArrayList<Shoes> shoesList = new ArrayList<>();
        for(Product p : prods){
            if(p instanceof Shoes){
                shoesList.add((Shoes) p);
                //System.out.println(((Shoes) p).getSize());
            }
        }
        for(Shoes s : shoesList){
            s.getSize();
        }
        for(int i=0; i<prods.size();i++){
            Product p = prods.get(i);
            if(p instanceof Shoes){
                System.out.println(((Shoes) p).getSize());
            }
        }
    }
}