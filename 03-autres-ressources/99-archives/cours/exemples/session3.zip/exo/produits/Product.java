package exo.produits;

public class Product {
    private String name;
    private int price;
    private int shippingCosts;

    public Product(){

    }
    public Product(String name, int price, int shippingCosts){
        this.name = name;
        this.price = price;
        this.shippingCosts = shippingCosts;
    }

    public String getName() {
        return this.name;
    }
    public int getPrice(){
        return this.price;
    }
    public int getShippingCosts(){
        return this.shippingCosts;
    }
}
