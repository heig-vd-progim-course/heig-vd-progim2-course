package exo.produits;

public class Shoes extends Product {
    int size;

    public Shoes(String name, int price, int shippingCosts, int size){
        super(name, price, shippingCosts);
        this.size = size;
    }
    public Shoes(){
        super();
    }
    public int getSize(){
        return this.size;
    }
}
