package exo.produits;

import java.util.ArrayList;

public class ShoppingCart {
    private ArrayList<Product> produits = new ArrayList<>();

    public void addProduct(Product prod){
        this.produits.add(prod);
    }

    public ArrayList<Product> getProduits(){
        return this.produits;
    }

    public int getTotalShoppingCart(){
        int total = 0;
        for(Product prod : this.produits){
            total += prod.getPrice()+ prod.getShippingCosts();
        }
        return total;
    }

}
