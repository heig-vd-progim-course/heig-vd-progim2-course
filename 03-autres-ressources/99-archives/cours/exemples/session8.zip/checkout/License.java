package checkout;

import java.util.Objects;

public class License extends Product implements Downloadable {
    private double version;
    private String link;


    public License(String name, int price,  double version, String link) {
        super(name, price);
        this.version = version;
        this.link = link;
    }

    @Override
    public double getShippingCosts() {
        return 0;
    }

    @Override
    public String getDownloadLink() {
        return this.link;
    }

    @Override
    public double getVersion() {
        return this.version;
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof License ){
            License l = (License) o;
            return l.getName().equals(this.getName()) && l.getPrice() == this.getPrice()
            && l.getVersion() == this.getVersion() && l.getDownloadLink().equals(this.getDownloadLink());
        }
        return false;
    }

    @Override
    public int hashCode(){
        return Objects.hash(this.getName(), this.getPrice(), this.getVersion(), this.getDownloadLink());
    }

}
