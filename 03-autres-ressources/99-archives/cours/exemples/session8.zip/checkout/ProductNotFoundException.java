package checkout;

public class ProductNotFoundException extends Exception{
}
