package checkout;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class MyFileReader {
    private BufferedReader br;

    public MyFileReader(String filePath) throws FileNotFoundException {
        br = new BufferedReader(new FileReader(filePath));
    }

    public String readNextLine() throws IOException {
        return br.readLine();
    }

    public void close() throws IOException{
        br.close();
    }

}
