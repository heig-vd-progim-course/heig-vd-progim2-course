package checkout;

public interface ProductFinder {

    Product findById(Integer id) throws ProductNotFoundException;
    void addProduct(Product p);
    void clear();
}
