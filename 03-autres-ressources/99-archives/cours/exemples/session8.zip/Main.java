import checkout.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


public class Main extends Object{
    public static void main(String[] args)  {

        Shoes shoes1 = new Shoes("shoes1", 49, 39);
        Shoes shoes2 = new Shoes("shoes1", 559, 29);
        Table table1 = new Table("table1", 539, 209);
        App app1 = new App("app1", 9, 1.1, "https://");
        License lic1 = new License("lic1", 39, 2.2, "https://");

        /*MyFileReader mfr = null;
        try {
             mfr = new MyFileReader("src/testfile.txt");
            System.out.println(mfr.readNextLine());

        }
        catch(FileNotFoundException fnf){
            System.out.println("File not found");
        }
        catch(IOException ioe){
            System.out.println("IO exception");
        }
        finally {
            try {
                mfr.close();
            }
            catch(IOException ioe){

            }
        }



      /* int i = 10;
        int j = 0;
        if(j!=0)
            System.out.println(i / j);
        try {
            System.out.println(i / j);
        }
        catch(ArithmeticException e){
            System.out.println(e.getMessage());
            //e.printStackTrace();
        }
        System.out.println("hello");


       /* Set<String> monSet = new HashSet<>();
        monSet.add("aaa");
        monSet.add("aab");
        System.out.println(monSet.add("aac"));
        System.out.println(monSet.add("aac"));
        System.out.println(monSet.size());

        for(String s : monSet){
            System.out.println(s);
        }*/
       /* Set<App> appSet = new HashSet<>();
        appSet.add(app1);
        App app2 = new App("app2", 9, 1.1, "https://");
        appSet.add(app2);
        System.out.println(appSet.size());
        App app3 = new App("app2", 9, 1.1, "https://");
        appSet.add(app3);
        System.out.println(appSet.size());
        App app4 = app3;
        appSet.add(app4);
        System.out.println(appSet.size());*/
        /*Set<License> licenses =new HashSet<>();
        licenses.add(lic1);
        System.out.println(licenses.size());
        License lic2 = new License("lic1", 39, 2.2, "https://");
        System.out.println(licenses.add(lic2));
        System.out.println(licenses.size());*/

        /*Map<Integer, String> monMap = new TreeMap<>(new IntegerComparator());
        monMap.put(300, "aaaa");
        monMap.put(200, "aaab");
        monMap.put(400, "aaac");
        monMap.put(100, "aaac");

        //System.out.println(monMap.get(1));
        for(Map.Entry<Integer, String> entry : monMap.entrySet()){
            System.out.println(entry.getKey() + ", " + entry.getValue());
        }*/

        /*Map<String, String> monMap2 = new TreeMap<>(new StringComparator());
        monMap2.put("aaad", "aaaa");
        monMap2.put("aaab", "aaab");
        monMap2.put("baaa", "aaac");
        monMap2.put("aaaa", "aaac");*/

       // System.out.println("aaa".compareTo("zzz"));



        //System.out.println(monMap.get(1));
        /*for(Map.Entry<String, String> entry : monMap2.entrySet()){
            System.out.println(entry.getKey() + ", " + entry.getValue());
        }*/
        ProductFinder pf = new ProductFinderList();
        pf.addProduct(shoes1);
        pf.addProduct(shoes2);
       // pf.addProduct(es2);
        pf.addProduct(table1);
        pf.addProduct(app1);

        try {
            System.out.println(pf.findById(41));
        }
        catch (ProductNotFoundException pnf){
            System.out.println("product not found");
        }

/*
        for(Map.Entry<Integer, Product> entry : pf.getProds().entrySet()){
            System.out.println(entry.getKey() + ", " + entry.getValue());
        }*/

    }
}