import ch.heigvd.checkout.CreditCard;
import ch.heigvd.checkout.User;

public class Main {
    public static void main(String[] args) {

        User user = new User("Gino", "Lastname", 21);
        user.addCreditCard("VISA", 1223333333333333L);
        user.addCreditCard("MASTERCARD", 443333444433333333L);

        System.out.println(user.getName() + ", cards: ");
        for (CreditCard cc : user.getCreditCards())
            System.out.println(cc.getType() + ": " + cc.getCcNumber());

    }
}