package ch.heigvd.checkout;

import java.util.ArrayList;

public class User {
    private String firstName;
    private String lastName;
    private int age;
    private ArrayList<CreditCard> creditCards;

    public User(String firstName, String lastName, int age){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.creditCards = new ArrayList<>();
    }

    public void addCreditCard(String type, long ccNumber){

        this.creditCards.add(new CreditCard(type, ccNumber));
    }

    public ArrayList<CreditCard> getCreditCards(){
        return this.creditCards;
    }

    public String getName() {
        return firstName + " " + lastName;
    }
}
