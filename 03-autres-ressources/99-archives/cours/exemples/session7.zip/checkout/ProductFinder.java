package checkout;

public interface ProductFinder {

    Product findById(Integer id);
    void addProduct(Product p);
    void clear();
}
