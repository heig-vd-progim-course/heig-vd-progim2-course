package exo3;

import java.math.BigDecimal;

public class BankAccount {
    private static BigDecimal interestRatePercent = BigDecimal.valueOf(0);//Default

    private long accountNumber;
    private BigDecimal balance;

    public BankAccount(long accountNumber){
        this.accountNumber = accountNumber;
        this.balance = BigDecimal.valueOf(0);
    }

    public void deposit(BigDecimal amount){
        this.balance = this.balance.add(amount);
    }
    public BigDecimal getBalance(){
        return this.balance;
    }
    public long getAccountNumber(){
        return this.accountNumber;
    }

    public static void setInterestRatePercent(BigDecimal interestRate){
        interestRatePercent = interestRate;
    }

    public static BigDecimal getInterestRatePercent(){
        return interestRatePercent;
    }
}
