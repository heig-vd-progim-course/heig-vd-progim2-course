package exo3;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        BankAccount ba = new BankAccount(123456L);

        System.out.println(BankAccount.getInterestRatePercent());
        System.out.println(ba.getInterestRatePercent());
        BankAccount.setInterestRatePercent(BigDecimal.valueOf(2.5));
        System.out.println(BankAccount.getInterestRatePercent());
        System.out.println(ba.getInterestRatePercent());


    }
}
