package exo2;

public class Main {
    public static void main(String[] args) {
        BankAccount ba = new BankAccount(123456L, 1000.0);

        PaymentMethod cb = new CreditCardPayment("12345678910", "Gino", "2027-01-01");
        PaymentMethod paypal = new PaypalPayment("aa@aa.com");
        PaymentMethod bitcoins = new BitcoinPayment("mywallet");

        PaymentMethod[] methods = {cb, paypal, bitcoins};

        for (PaymentMethod pm : methods){
            pm.pay(100.0, ba);
            System.out.println("Solde: " + ba.getBalance());
        }
    }
}
