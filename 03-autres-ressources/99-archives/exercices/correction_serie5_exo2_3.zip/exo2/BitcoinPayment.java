package exo2;

public class BitcoinPayment implements PaymentMethod {
    private String walletAddress;

    public BitcoinPayment(String walletAddress) {
        this.walletAddress = walletAddress;
    }

    @Override
    public void pay(double amount, BankAccount destinationAccount) {
        System.out.println("Debiting Wallet: " + this.walletAddress);
        System.out.println("Crediting account: " + destinationAccount.getAccountNumber());
        destinationAccount.deposit(amount);
    }
}
