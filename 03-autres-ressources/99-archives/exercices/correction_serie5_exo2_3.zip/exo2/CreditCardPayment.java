package exo2;

public class CreditCardPayment implements PaymentMethod{
    String cardnumber;
    String cardHolder;
    String expiryDate;

    public CreditCardPayment(String cardnumber, String cardHolder, String expiryDate) {
        this.cardnumber = cardnumber;
        this.cardHolder = cardHolder;
        this.expiryDate = expiryDate;
    }

    @Override
    public void pay(double amount, BankAccount destinationAccount) {
        System.out.println("Debiting CB: " + this.cardHolder + ", " + this.cardnumber + this.expiryDate);
        System.out.println("Crediting account: " + destinationAccount.getAccountNumber());
        destinationAccount.deposit(amount);
    }
}
