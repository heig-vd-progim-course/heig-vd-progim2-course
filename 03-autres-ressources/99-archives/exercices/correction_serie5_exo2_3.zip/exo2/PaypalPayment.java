package exo2;

public class PaypalPayment implements PaymentMethod {
    private String email;

    public PaypalPayment(String email) {
        this.email = email;
    }

    @Override
    public void pay(double amount, BankAccount destinationAccount) {
        System.out.println("Debiting Paypal: " + this.email);
        System.out.println("Crediting account: " + destinationAccount.getAccountNumber());
        destinationAccount.deposit(amount);
    }
}
