package exo2;

interface PaymentMethod {
    void pay(double amount, BankAccount destinationAccount);
}