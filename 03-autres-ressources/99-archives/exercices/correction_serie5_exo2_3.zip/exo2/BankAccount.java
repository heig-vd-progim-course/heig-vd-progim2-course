package exo2;

public class BankAccount {
    private long accountNumber;
    private double balance;

    public BankAccount(long accountNumber, double balance){
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public void deposit(double amount){
        this.balance += amount;
    }
    public double getBalance(){
        return this.balance;
    }
    public long getAccountNumber(){
        return this.accountNumber;
    }
}
