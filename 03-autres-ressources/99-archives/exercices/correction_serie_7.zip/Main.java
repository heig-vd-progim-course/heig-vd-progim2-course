import exo2.Student;
import exo2.StudentsManager;
import exo3.PrintingJob;
import exo3.PrintingJobManager;
import exo4.StudentCoursesManager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {

        //test exo2
        Student stu1 = new Student(1, "stu1", BigDecimal.valueOf(5.1));
        Student stu2 = new Student(2, "stu2", BigDecimal.valueOf(6));
        Student stu3 = new Student(3, "stu3", BigDecimal.valueOf(4.1));
        Student stu4 = new Student(4, "stu4", BigDecimal.valueOf(3.1));

        List<Student> students = new ArrayList<>();
        students.add(stu1);
        students.add(stu2);
        students.add(stu3);
        students.add(stu4);

        StudentsManager studentsManager = new StudentsManager();

        studentsManager.fillStudentsMap(students);
        Set<Student> stusWith6 = studentsManager.getStudentsWith6();

        System.out.println(stusWith6.size());

        //test exo3
        PrintingJob job1 = new PrintingJob(1);
        PrintingJob job2 = new PrintingJob(2);
        PrintingJobManager manager = new PrintingJobManager(false);
        manager.addJob(job1);
        manager.addJob(job2);

        System.out.println(manager.processJob().getId());

        //test exo4
        List<String> coursesJim = new ArrayList<>();
        coursesJim.add("Maths");
        coursesJim.add("History");
        coursesJim.add("Physics");

        List<String> coursesJohn = new ArrayList<>();
        coursesJohn.add("Maths");
        coursesJohn.add("Geography");
        coursesJohn.add("Politics");

        StudentCoursesManager scm = new StudentCoursesManager();
        scm.addStudent("Jim", coursesJim);
        scm.addStudent("John", coursesJohn);

        //doit être 5
        System.out.println(scm.getUniqueCourses().size());
        List<String> studentsWithMaths = scm.findStudentswithCourse("Maths");
        //doit être 2
        System.out.println(studentsWithMaths.size());
    }
}