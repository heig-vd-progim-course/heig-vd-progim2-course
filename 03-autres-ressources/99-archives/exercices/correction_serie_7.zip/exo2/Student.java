package exo2;

import java.math.BigDecimal;

public class Student {
    private Integer id;
    private String name;
    private BigDecimal grade;

    public Student(Integer id, String name, BigDecimal grade){
        this.id = id;
        this.name = name;
        this.grade = grade;
    }
    public Integer getId(){
        return this.id;
    }
    public String getName(){
        return this.name;
    }
    public BigDecimal getGrade(){
        return this.grade;
    }
}