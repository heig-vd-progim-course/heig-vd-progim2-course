package exo2;

import java.math.BigDecimal;
import java.util.*;

public class StudentsManager {
    private Map<Integer, Student> studentsMap = new HashMap<>();


    public void fillStudentsMap(List<Student> students){
        for(Student s : students){
            this.studentsMap.put(s.getId(), s);
        }
    }

    public Set<Student> getStudentsWith6(){
        // autre possibilité: return new HashSet<>(this.studentsMap.values());
        Set<Student> students = new HashSet<>();
        for(Map.Entry<Integer, Student> studentEntry : this.studentsMap.entrySet()){
            if(studentEntry.getValue().getGrade().equals(BigDecimal.valueOf(6))){
                students.add(studentEntry.getValue());
            }
        }
        return students;
    }
}
