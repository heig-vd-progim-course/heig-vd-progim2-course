package exo4;

import java.util.*;

public class StudentCoursesManager {

    //map des étudiants (clé = nom), liste des matières (string)
    private Map<String, List<String>> studentCourses = new HashMap<>();

    private Set<String> uniqueCourses = new HashSet<>();


    public void addStudent(String studentName, List<String> courses){

        //1. vérifier que studentCourses ne contient pas déjà le même étudiant
        //   si c'est le cas, alors ne rien faire et sortir de la méthode
        //2. Ajouter l’étudiant à studentCourses
        //3. Ajouter tous les cours de l’étudiant au set uniqueCourses, sans doublons
        if(!this.studentCourses.containsKey(studentName)){
            this.studentCourses.put(studentName, courses);
            this.uniqueCourses.addAll(courses); // ou boucle avec add
        }
    }
    public Set<String> getUniqueCourses(){
        return this.uniqueCourses;
    }

    public void removeStudent(String studentName) {
        // Eliminer un étudiant de studentCourses
        this.studentCourses.remove(studentName);
    }


    public List<String> findStudentswithCourse(String course){

        //retourner la liste de tous les étudiants inscrit au cours passé en
        // paramètre
        List<String> courses = new ArrayList<>();
        for(Map.Entry<String, List<String>> studentCourse : this.studentCourses.entrySet()) {
            if (studentCourse.getValue().contains(course)) {
                courses.add(course);
            }
        }
        return courses;
    }
}
