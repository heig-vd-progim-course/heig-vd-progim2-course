package exo3;

import java.util.ArrayDeque;
import java.util.Deque;

public class PrintingJobManager {
    private Deque<PrintingJob> jobs = new ArrayDeque<>();
    private boolean isFIFO;

    public PrintingJobManager(boolean isFIFO){
        this.isFIFO = isFIFO;
    }

    public void addJob(PrintingJob job){
        if (this.isFIFO)
            this.jobs.add(job);
        else
            this.jobs.push(job);
    }

    public PrintingJob processJob(){
        if(this.isFIFO)
            return this.jobs.poll();
        return this.jobs.pop();
    }
}
