package exo3;

public class PrintingJob{
    private long id;

    public PrintingJob(long id){
        this.id = id;
    }
    public long getId(){
        return this.id;
    }
}