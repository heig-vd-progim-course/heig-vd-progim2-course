package exo3;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        SmartPhone sd1 = new SmartPhone();
        sd1.setBatteryLevel(50);
        sd1.turnOn();
        SmartWatch sd2 = new SmartWatch();
        sd2.incrementSteps();

        ArrayList<SmartDevice> devices = new ArrayList<>();

        devices.add(sd1);
        devices.add(sd2);

        for(SmartDevice sd : devices){
            sd.performFunction();
        }
    }
}
