package exo3;

public class SmartWatch extends SmartDevice {
    private int stepCount = 0;

    @Override
    public void performFunction() {
        System.out.println("Nombre de pas: " + this.stepCount);
    }

    public void incrementSteps(){
        stepCount++;
    }
}
