package exo3;

public class SmartPhone extends SmartDevice {
    private double batteryLevel;

    @Override
    public void performFunction() {
        if(this.isOn() && this.batteryLevel > 0){
            System.out.println("Appel en cours");
        }
    }

    public void setBatteryLevel(double level){
        this.batteryLevel = level;
    }
}
