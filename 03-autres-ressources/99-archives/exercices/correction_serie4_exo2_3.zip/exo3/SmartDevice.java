package exo3;

abstract class SmartDevice {
    private boolean isOn ;
    public void turnOn(){
        this.isOn = true ;
    }
    public void turnOff(){
        this.isOn = false ;
    }
    public boolean isOn() {
        return this.isOn;
    }
    public abstract void performFunction() ;
}