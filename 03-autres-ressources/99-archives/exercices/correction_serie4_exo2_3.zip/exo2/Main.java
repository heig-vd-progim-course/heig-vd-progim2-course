package exo2;

abstract class Shape {
    private String name;

    public Shape(String name){
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
    public void displayInfo() {
        System.out.println("Name: " + this.getName()
                + ", Area: "+ this.calculateArea()
        + ", Perimeter: "+ this.calculatePerimeter());
    }
    public abstract double calculateArea();
    public abstract double calculatePerimeter();

}

class Circle extends Shape {
    double radius;

    public Circle(double radius){
        super("circle");
        this.radius = radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * (Math.pow(this.radius,2));
    }

    @Override
    public double calculatePerimeter() {
        return 2.0 * Math.PI * this.radius;
    }
}

class Square extends Shape {
    double side;

    public Square(double side){
        super("square");
        this.side = side;
    }

    @Override
    public double calculateArea() {
        return Math.pow(this.side,2);
    }

    @Override
    public double calculatePerimeter() {
        return 4.0 * this.side;
    }
}

class Rectangle extends Shape {
    double longSide;
    double shortSide;

    public Rectangle(double longSide, double shortSide){
        super("rectangle");
        this.longSide = longSide;
        this.shortSide = shortSide;
    }

    @Override
    public double calculateArea() {
        return this.longSide * this.shortSide;
    }

    @Override
    public double calculatePerimeter() {
        return (this.longSide + this.shortSide) * 2.0;
    }
}

class Triangle extends Shape {
    double a;
    double b;
    double c;

    public Triangle(double a, double b, double c){
        super("triangle");
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double calculateArea() {
        double semiPerimeter = this.calculatePerimeter() / 2.0;
        return Math.sqrt(semiPerimeter*(semiPerimeter-this.a)*(semiPerimeter-this.b)*(semiPerimeter-this.c));
    }

    @Override
    public double calculatePerimeter() {
        return this.a + this.b + this.c;
    }
}

public class Main {

    public static void main(String[] args) {
        Shape circle = new Circle(3.0);
        Shape square = new Square(3.0);
        Shape rectangle = new Rectangle(3.0, 4.0);
        Shape triangle = new Triangle(2.0,3.0,4.0);

        circle.displayInfo();
        square.displayInfo();
        rectangle.displayInfo();
        triangle.displayInfo();
    }

}
