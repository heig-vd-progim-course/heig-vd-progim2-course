class BankAccount {
    String iban;
    int amount;
    boolean isOpen;

    /* Constructor
     * Arguments are IBAN and initial amount
     */
    BankAccount(String iban, int initialAmount){
        if(initialAmount >= 100) {
            this.isOpen = true;
            this.amount = initialAmount;
            this.iban = iban;
        }
    }

    // Checks if account is open
    String isAccountOpen(){
        return this.isOpen?"open":"closed";
    }

    // Returns the total amount available on the account
    int getAmount(){
        return this.amount;
    }

    // Adds money to account
    // Returns true if success, else false
    boolean addMoney(int amountToAdd){
        if(this.isOpen) {
            this.amount += amountToAdd;
            return true;
        }
        return false;
    }

    // Draws money from account
    // Returns true if success, else false
    boolean drawMoney(int amountToDraw){
        if(this.isOpen) {
            if (this.amount >= amountToDraw) {
                this.amount -= amountToDraw;
                return true;
            }
        }
        return false;
    }
}
