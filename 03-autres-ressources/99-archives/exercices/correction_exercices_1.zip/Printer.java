class Printer {
    boolean isOn;

    // allume l'imprimante
    void turnOn(){
        this.isOn = true;
    }

    // éteins l'imprimante
    void turnOff(){
        this.isOn = false;
    }

    // vérifie si l'imprimante est allumée
    String isOn(){
        return this.isOn?"on":"off";
    }
}
