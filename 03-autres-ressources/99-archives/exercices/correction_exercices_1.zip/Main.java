
public class Main {
    public static void main(String[] args) {
        //exo1
        Printer imprimante = new Printer();
        imprimante.turnOn();
        imprimante.turnOff();
        System.out.println(imprimante.isOn());

        //exo2
        Car myCar = new Car("Toyota", "Corolla", 2022, "rouge");

        myCar.start();
        System.out.println("The car is "+myCar.isStarted());
        int currentSpeed = myCar.accelerate(50);
        System.out.println("The car is accelerating. Current speed: "+currentSpeed);
        currentSpeed = myCar.brake();
        System.out.println("The car is braking. Current speed: "+currentSpeed);
        myCar.stop();
        System.out.println("The car is "+myCar.isStarted());

        //exo3
        BankAccount ba = new BankAccount("CH12 3456 7890 1234 5", 150);
        System.out.println("Account is: " + ba.isAccountOpen());
        if(ba.isAccountOpen().equals("open")) {
            boolean success = ba.addMoney(200);
            if (success){
                System.out.println("Current balance is: " + ba.getAmount());
            }
            success = ba.drawMoney(100);
            if (success){
                System.out.println("Current balance is: " + ba.getAmount());
            }
            else {
                System.out.println("Withdrawal failed");
            }
            success = ba.drawMoney(300);
            if (success){
                System.out.println("Current balance is: " + ba.getAmount());
            }
            else {
                System.out.println("Withdrawal failed");
            }
        }
    }
}