class Car {
    String brand;
    String model;
    int year;
    String color;
    boolean isStarted;
    int currentSpeed;

    /* Constructor
     * Arguments are brand, model, year of construction and color of the car
     */
    Car(String brand, String model, int year, String color) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.color = color;
        this.isStarted = false; // Represents whether the car is started or not
        this.currentSpeed = 0; // Represents the current speed of the car
    }

    // Method to start the car
    void start() {
        this.isStarted = true;
    }

    // Method to stop the car
    void stop() {
        this.isStarted = false;
        this.currentSpeed = 0; // Reset the current speed when the car stops
    }

    //Checks if the car is started
    String isStarted(){
        return this.isStarted?"started":"stopped";
    }

    /* Method to accelerate the car
     * Argument is speed increment
     * Returns updated speed
     */
    int accelerate(int speedIncrement) {
        if (this.isStarted) {
            this.currentSpeed += speedIncrement;
            return this.currentSpeed;
        } else {
            return 0;
        }
    }

    /* Method to reduce speed
     * Returns updated speed
     */
    int brake() {
        if (this.getCurrentSpeed() > 0) {
            this.currentSpeed -= 10;
            return this.currentSpeed;
        } else {
            return 0;
        }
    }

    // Returns current speed
    int getCurrentSpeed(){
        return this.currentSpeed;
    }
}