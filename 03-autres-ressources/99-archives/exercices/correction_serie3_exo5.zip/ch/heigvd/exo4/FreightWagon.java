package ch.heigvd.exo4;

public class FreightWagon extends Wagon{
    String type;
    int weight;
}
