package ch.heigvd.exo4;

public class PassengerWagon extends Wagon{
    int passengersNumber;
}
