package ch.heigvd.exo4;

import java.util.ArrayList;

public class Train {
    ArrayList<Wagon> wagons = new ArrayList<>();

    public void addWagon(Wagon wagon){
        if(!this.wagons.isEmpty()) {
            if (!wagon.isMustBeOnTop()) {
                this.wagons.add(wagon);
            }
        }
        else {
            this.wagons.add(wagon);
        }
    }

    public void showComposition(){
        for (Wagon w: this.wagons) {
            System.out.println(w);
        }
    }
}
