package ch.heigvd.exo4;

public class Wagon {
    private int length;
    protected boolean mustBeOnTop;

    public int getLength() {
        return length;
    }

    public boolean isMustBeOnTop() {
        return mustBeOnTop;
    }
}
