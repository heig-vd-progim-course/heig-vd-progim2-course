package ch.heigvd.exo4;

public class Locomotive extends Wagon{

    public Locomotive(){
        this.mustBeOnTop = true;
    }
}
