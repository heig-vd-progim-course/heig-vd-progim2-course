
import ch.heigvd.exo4.FreightWagon;
import ch.heigvd.exo4.Locomotive;
import ch.heigvd.exo4.PassengerWagon;
import ch.heigvd.exo4.Train;

public class Main {
    public static void main(String[] args) {

        //Exo 4
        Train train1 = new Train();
        Train train2 = new Train();

        Locomotive loco = new Locomotive();
        PassengerWagon pw = new PassengerWagon();
        FreightWagon fw = new FreightWagon();
        train1.addWagon(loco);
        train1.addWagon(pw);
        train1.addWagon(fw);
        train1.showComposition();
        train2.addWagon(pw);
        train2.addWagon(fw);
        train2.addWagon(loco);
        train2.showComposition();



    }
}
