package exo4;

import exo4.classes.Consumer;
import exo4.classes.EmptyListException;
import exo4.classes.IConsumer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        List<String> inputList = new ArrayList<>();
        inputList.add("a");
        inputList.add("b");
        inputList.add("c");
        inputList.add("b");
        inputList.add("c");
        inputList.add("bb");
        inputList.add("cc");

        IConsumer consumer  = new Consumer();
        consumer.computeList(inputList);
        try {
            Map<String, Integer> results = consumer.getMatchingKeys("b");
            System.out.println(results.size());
            System.out.println(results.get("b"));
            System.out.println(results.get("bb"));
            consumer  = new Consumer();
            consumer.getMatchingKeys("b");
        } catch (EmptyListException e) {
            System.out.println("La liste est vide");
        }
    }
}
