package exo4.classes;

import java.util.*;

public class Consumer implements IConsumer{

    Map<String, Integer> aMap = new HashMap<>();

    @Override
    public void computeList(List<String> inputList){
        for(String el : inputList){
            Integer currentCount = aMap.get(el);
            if(currentCount == null){
                currentCount = 0;
            }
            currentCount++;
            aMap.put(el, currentCount);
        }

    }

    @Override
    public Map<String, Integer> getMatchingKeys(String keyPrefix) throws EmptyListException {
        Map<String, Integer> results = new HashMap<>();
        if (this.aMap.isEmpty()){
            throw new EmptyListException();
        }
        for(Map.Entry<String, Integer> entry : this.aMap.entrySet()){
            if(entry.getKey().startsWith(keyPrefix)){
                results.put(entry.getKey(), entry.getValue());
            }
        }
        return results;
    }
}
