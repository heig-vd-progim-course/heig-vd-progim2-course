package exo4.classes;

import java.util.List;
import java.util.Map;

public interface IConsumer {

    public void computeList(List<String> inputList);

    public Map<String, Integer> getMatchingKeys(String keyPrefix) throws EmptyListException;
}
