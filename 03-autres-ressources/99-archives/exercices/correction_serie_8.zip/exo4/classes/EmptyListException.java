package exo4.classes;

public class EmptyListException extends Exception{
}
