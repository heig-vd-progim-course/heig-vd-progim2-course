package exo2.classes;

public abstract class AbstractClasse {

    public String displayMyMessage(){
        return "This message was generated in AbstractClasse";
    }

    public abstract String displayMyMessage2();
}
