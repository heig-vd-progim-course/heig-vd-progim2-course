package exo2.classes;

public class ConcreteClasse extends AbstractClasse{

    @Override
    public String displayMyMessage() {
        return "This message was generated in ConcreteClasse";
    }

    @Override
    public String displayMyMessage2() {
        return "Message2 was generated in ConcreteClasse";
    }
}
