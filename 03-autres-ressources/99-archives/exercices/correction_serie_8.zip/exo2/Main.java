package exo2;

import exo2.classes.AbstractClasse;
import exo2.classes.ConcreteClasse;

public class Main {
    public static void main(String[] args) {

        AbstractClasse myClasse = new ConcreteClasse();

        System.out.println(myClasse.displayMyMessage());
        System.out.println(myClasse.displayMyMessage2());
    }
}
