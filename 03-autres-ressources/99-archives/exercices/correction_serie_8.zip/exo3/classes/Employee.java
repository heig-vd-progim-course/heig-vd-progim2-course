package exo3.classes;

public class Employee {
    private String name;
    private String department;
    private int seniorityLevel;

    public Employee(String name, String department, int seniorityLevel){
        this.name = name;
        this.department = department;
        this.seniorityLevel = seniorityLevel;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public int getSeniorityLevel() {
        return seniorityLevel;
    }
}
