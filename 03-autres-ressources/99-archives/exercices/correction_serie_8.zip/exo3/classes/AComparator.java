package exo3.classes;

import java.util.Comparator;

public class AComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        int depCompare = e1.getDepartment().compareTo(e2.getDepartment());
        if(depCompare != 0 ){
            return depCompare;
        }
        else {
            //descendant
            int seniorityCompare = -1*(e1.getSeniorityLevel() - e2.getSeniorityLevel());
            if(seniorityCompare != 0){
                return seniorityCompare;
            }
            else {
                return e1.getName().compareTo(e2.getName());
            }

        }
    }
}
