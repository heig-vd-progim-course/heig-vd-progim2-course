package exo3;

import exo3.classes.AComparator;
import exo3.classes.Employee;

import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        Employee e1 = new Employee("aaa", "dep1", 1);
        Employee e2 = new Employee("aaa", "dep2", 1);
        Employee e3 = new Employee("aab", "dep2", 2);
        Employee e4 = new Employee("aac", "dep1", 1);
        Employee e5 = new Employee("aad", "dep1", 1);
        Employee e6 = new Employee("aae", "dep1", 1);

        TreeSet<Employee> aTrier = new TreeSet<>(new AComparator());
        aTrier.add(e1);
        aTrier.add(e2);
        aTrier.add(e3);
        aTrier.add(e4);
        aTrier.add(e5);
        aTrier.add(e6);

        for(Employee e : aTrier){
            System.out.println(e.getName()+", "+ e.getDepartment()+", " + e.getSeniorityLevel());
        }




    }
}
