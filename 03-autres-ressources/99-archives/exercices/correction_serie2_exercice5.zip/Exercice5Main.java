import ch.comem.printer.PaperSheet;
import ch.comem.printer.Printer;

public class Exercice5Main {
    public static void main(String[] args) {
        Printer printer = new Printer();
        printer.print("test"); // N'imprime rien, puisque l'imprimante n'est pas allumée
        printer.turnOn();
        printer.print("test"); // N'imprime rien, puisque il n'y avait pas de feuilles
        PaperSheet sheet = new PaperSheet();
        printer.addPaperSheet(sheet);
        printer.print("test"); // Une feuille contenant "test" est disponible dans le bac
        PaperSheet printedSheet = printer.ejectPrintedPaperSheet();
        System.out.println(printedSheet.getContent()); // affiche "test"
        printer.turnOff();
    }

}