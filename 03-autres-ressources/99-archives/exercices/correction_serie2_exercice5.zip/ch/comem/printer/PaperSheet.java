package ch.comem.printer;

public class PaperSheet {
    private String content;

     //Crée une feuille blanche
    public PaperSheet() {
        this.content = "";
    }

    public void addText(String text) {
        this.content += text;
    }

    public String getContent() {
        return this.content;
    }
}
