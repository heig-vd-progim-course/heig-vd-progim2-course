package ch.comem.printer;

import java.util.ArrayList;

public class Printer {
    private boolean isOn;
    private ArrayList<PaperSheet> paperSheetsInPrinter;

    // Initialise l'imprimante avec un bac de feuilles vide
    public Printer(){
        this.paperSheetsInPrinter = new ArrayList<>();
        this.isOn = false;
    }

    public void turnOn(){

        this.isOn = true;
    }

    public void turnOff(){

        this.isOn = false;
    }

    public String isOn(){
        return this.isOn?"on":"off";
    }

    public void print(String toPrint){
        if(this.isOn){
            if(this.paperSheetsInPrinter.size() > 0){
                this.paperSheetsInPrinter.get(0).addText(toPrint);
            }
        }
    }

    // Ajoute une feuille blanche à l'imprimante
    public void addPaperSheet(PaperSheet paperSheet){
        this.paperSheetsInPrinter.add(paperSheet);
    }

    // Enleve la feuille de l'imprimante et la retourne
    public PaperSheet ejectPrintedPaperSheet(){
        if(this.paperSheetsInPrinter.size() > 0) {
            // la méthode remove retourne l'objet enlevà de la liste
            return this.paperSheetsInPrinter.remove(0);
        }
        return null;
    }
}
