package exo1;

import java.util.ArrayList;
import java.util.List;

abstract class Task {
    private String name;

    public Task(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract int execute();
}

class ComputeTask extends Task {
    public ComputeTask(String name) {
        super(name);
    }

    // TODO: override de la méthode execute() qui retourne la longueur du nom * 2
    @Override
    public int execute() {
        return this.getName().length() * 2;
    }

}

class CheckTask extends Task {
    public CheckTask(String name) {
        super(name);
    }

    // TODO: override de la méthode execute() qui retourne 1 si le nom commence avec "Check", sinon 0
    @Override
    public int execute() {
        if(this.getName().startsWith("Check"))
            return 1;
        return 0;
    }
}

public class Runner {

    public static void runTasks(List<Task> tasks, List<Integer> results) {
        //pour chaque task de la liste, exécuter la méthode “execute” et stocker le résultat dans la liste “results”
        for(Task t : tasks){
            results.add(t.execute());
        }


    }

    public static void printTotal(List<Integer> results) {
        // Afficher la somme des résultats
        Integer somme = 0;
        for(Integer result : results){
            somme += result;
        }
        System.out.println(somme);
    }

    public static void main(String[] args) {
        //1. créer une liste de Tasks
        //2. ajouter 3 taches: 2 ComputeTask, 1 CheckTask
        //3. créer une liste pour les résultats
        //4.exécuter runTasks + printTotal
        List<Task> tasks = new ArrayList<>();
        List<Integer> results = new ArrayList<>();
        ComputeTask ct1 = new ComputeTask("ct1");
        ComputeTask ct2 = new ComputeTask("ct2");
        CheckTask checkt = new CheckTask("checktask1");

        tasks.add(ct1);
        tasks.add(ct2);
        tasks.add(checkt);

        runTasks(tasks, results);
        printTotal(results);

    }
}
