package exo2;

public class NotificationManager {

    private NotificationService notificationService;

    public NotificationManager(NotificationService channel){
        this.notificationService = channel;
    }

    public void notifyUser(String recipient, String message){
        this.notificationService.sendNotification(recipient, message);
    }
}
