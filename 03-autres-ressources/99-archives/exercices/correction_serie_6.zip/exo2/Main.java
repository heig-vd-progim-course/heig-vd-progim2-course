package exo2;

public class Main {
    public static void main(String[] args) {
        NotificationService emailNotification = new EmailNotificationService();
        NotificationManager emailNm = new NotificationManager(emailNotification);
        emailNm.notifyUser("aa@aa.com", "a message");

        NotificationService smsNotification = new SmsNotificationService();
        NotificationManager smsNm = new NotificationManager(smsNotification);
        smsNm.notifyUser("+41791234567", "a message");
    }
}
