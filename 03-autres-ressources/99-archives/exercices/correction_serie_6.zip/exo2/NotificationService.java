package exo2;

public interface NotificationService {
    void sendNotification(String recipient, String message);
}
